    <meta charset="UTF-8">
    <meta name="keywords" content="watch,movies,tv,videos">
    <meta name="description" content="My interview task">
    <meta name="author" content="Thabani Chris Njoko">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS fontawesome-->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <!-- CSS bootstrap-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- CSS main-->
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>